package it.epicode.gi;

public interface CentroControlloInterface {

	public void check(SondaData sondaData);

}
