package it.epicode.gi;

public interface Observer {

	public void update(Subject obj);

}
