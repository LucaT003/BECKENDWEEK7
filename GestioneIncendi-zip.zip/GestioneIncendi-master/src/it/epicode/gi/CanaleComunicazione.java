package it.epicode.gi;

public abstract class CanaleComunicazione {
	// classe astratta usata per creare canali di comunicazione diversi
}
